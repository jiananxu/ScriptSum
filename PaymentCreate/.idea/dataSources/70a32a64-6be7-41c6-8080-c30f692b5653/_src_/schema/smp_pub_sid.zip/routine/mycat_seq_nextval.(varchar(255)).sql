CREATE FUNCTION mycat_seq_nextval(seq_name VARCHAR(255))
  RETURNS VARCHAR(64)
  BEGIN UPDATE unisequence SET current_value = current_value + increment WHERE NAME = seq_name; RETURN mycat_seq_currval(seq_name); 
END;

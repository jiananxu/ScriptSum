CREATE FUNCTION mycat_seq_currval(seq_name VARCHAR(255))
  RETURNS VARCHAR(64)
  BEGIN DECLARE retval VARCHAR(64); 
SET retval="-999999999,null"; 
SELECT CONCAT(CAST(current_value AS CHAR),",",CAST(increment AS CHAR)) INTO retval FROM unisequence WHERE NAME = seq_name; RETURN retval; 
END;

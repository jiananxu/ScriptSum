CREATE FUNCTION mycat_seq_setval(seq_name VARCHAR(255), VALUE INT)
  RETURNS VARCHAR(64)
  BEGIN UPDATE unisequence SET current_value = VALUE WHERE NAME = seq_name; RETURN mycat_seq_currval(seq_name); 
END;

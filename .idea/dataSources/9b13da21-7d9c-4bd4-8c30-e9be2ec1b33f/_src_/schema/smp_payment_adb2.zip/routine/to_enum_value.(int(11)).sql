CREATE FUNCTION to_enum_value(p_value_id INT)
  RETURNS VARCHAR(100)
  BEGIN
	DECLARE v_value_name VARCHAR(100) DEFAULT 'NONE#';
	select v.ENUM_VALUE_MEANING into v_value_name from smp_pub_sid.t_sac_pub_enum_value v where v.ENUM_VALUE_ID = p_value_id;
	RETURN v_value_name;
END;
